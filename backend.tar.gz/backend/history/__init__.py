
class LogType(object):
    CRATE_SERVER = '创建服务器'
    DELETE_SERVER = '删除服务器'
    UPDATE_SERVER = '更新服务器'
    UPDATE_CRON = '更新CRON'
    SYNC_CRON = '同步CRON'
